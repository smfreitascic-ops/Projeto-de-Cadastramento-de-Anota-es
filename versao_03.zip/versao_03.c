#include <stdio.h>
#include <string.h>

int main (){
	int opcao;
	char afazer[20][51];
	char andamento[20][51];
	char concluido[40][51];
	int qtd_afazer = 0;
    int qtd_andamento = 0;
    int qtd_concluido = 0;
	int i, move, opc, qtd_cadastro;
	printf("===========================================\n");
	printf("Organizacao de Atividades:\n");
	printf("1: Cadastrar atividade.\n");
	printf("2: Listar atividades.\n");
	printf("3: Movimentar atividades.\n");
	printf("4: Consultar quantidade de atividades.\n");
	printf("5: Buscar atividade.\n");
	printf("6: Sair.\n");
	printf("===========================================\n");
	printf("Informe o que deseja fazer: ");
	do{
		scanf("%d", &opcao);
		switch (opcao){
			case 1: 
				printf("===========================================\n");
				printf("CADASTRO DE ATIVIDADES\n");
				printf("===========================================\n");
				printf("Quantas atividades deseja registrar? ");
				
				scanf("%d", &qtd_cadastro);
				getchar();
				printf ("Insira o nome das atividades: \n");
				for(i = 0; i < qtd_cadastro; i++) {
                    if(qtd_afazer < 20) {
                        fgets(afazer[qtd_afazer], 51, stdin);
                        afazer[qtd_afazer][strcspn(afazer[qtd_afazer], "\n")] = '\0';
                        qtd_afazer++;
                    } else {
                        printf("Lista de A Fazer cheia!\n");
                        break;
                    }
                }
				break;
			case 2:
				printf("===========================================\n");
				printf("LISTA DE ATIVIDADES\n");      
				printf("===========================================\n");
			
				printf("AFAZER:\n");
                for(i = 0; i < qtd_afazer; i++) {
                    printf("  %d. %s\n", i + 1, afazer[i]);
                }
                
                printf("\nEM ANDAMENTO:\n");
                for(i = 0; i < qtd_andamento; i++) {
                    printf("  %d. %s\n", i + 1, andamento[i]);
                }
                
                printf("\nCONCLUIDO:\n");
                for(i = 0; i < qtd_concluido; i++) {
                    printf("  %d. %s\n", i + 1, concluido[i]);
                }
                break;
			case 3:
				printf("===========================================\n");
				printf("MOVIMENTAR ATIVIDADES\n");      
				printf("===========================================\n");
				printf("O que deseja mover?\n");
				printf("Opcao 1: AFAZER -> ANDAMENTO\n");
				printf("Opcao 2: ANDAMENTO -> CONCLUIDO\n");
			
				scanf("%d",&opc);
				switch(opc){
					case 1: 
						printf("Qual atividade deseja mover?\n");
						for(i=0;i<qtd_afazer;i++) {
						if (i==0){
							printf("AFAZER:\n");
						}
						printf("%d.%s\n",i+1,afazer[i]);
						}
						scanf("%d",&move);
						if(move >= 0 && move < qtd_afazer) {
                           
                            strcpy(andamento[qtd_andamento], afazer[move]);
                            qtd_andamento++;
                            
                         
                            for(i = move; i < qtd_afazer - 1; i++) {
                                strcpy(afazer[i], afazer[i + 1]);
                            }
                            qtd_afazer--; 
                            
                            printf("MOVIMENTACAO CONCLUIDA\n");
                        } else {
                            printf("Opcao invalida.\n");
                        }
                        break;
						break;
						
				}
		}
		if(opcao == 6){
			printf("Encerrando programa...");
			return 0;
		}
		if(opcao > 6 || opcao < 1){
			while(opcao > 6 || opcao < 1){
				printf("Selecao de opcao inexistente, por favor tente novamente: ");
				scanf("%d", &opcao);
				
			}
		}
		printf("Informe o que deseja fazer agora: ");
	}while(opcao != 6);
}
